//
//  MGTopWindow.h
//  MGMiaoBo
//
//  Created by ming on 16/9/10.
//  Copyright © 2016年 ming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MGTopWindow : NSObject
+ (void)show;
+ (void)hide;
@end
